# Backend setup — Supabase (step by step)

The app runs in two modes:

| Mode | When | What you get |
|------|------|--------------|
| **Demo** | no environment variables | in-memory data, role switcher (nothing is saved) |
| **Cloud** | `VITE_SUPABASE_URL` + `VITE_SUPABASE_ANON_KEY` set | login, real-time sync, role-based data access, evidence files in cloud storage |

## 1. Create the Supabase project
1. Go to <https://supabase.com> → **New project** (choose a region close to Israel, e.g. Frankfurt).
2. Wait until it finishes provisioning.

## 2. Create the database (tables, security, triggers, storage)
1. Open **SQL Editor → New query**.
2. Paste the entire contents of `supabase/schema.sql` and press **Run**.
3. This creates:
   - tables `profiles`, `orders`, `visits`, `notifications`, `settings`
   - Row Level Security policies (courier = only assigned orders, lawyer = only own orders, admin = everything)
   - triggers that create law-firm notifications on every visit and on completion
   - Realtime publication for all five tables
   - the public Storage bucket **`evidence`** (photos, video, audio, signatures) with upload policies

## 3. Configure authentication
1. **Authentication → Providers → Email**: keep *Email* enabled.
2. Keep **Confirm email** switched **ON** (recommended). Optional for quick tests: turn it off.
3. **Authentication → URL Configuration**: set *Site URL* to your deployed URL (or `http://localhost:5173` for local work).

## 4. Add the environment variables
Supabase → **Project Settings → API**: copy the **Project URL** and the **anon public** key.

Local development:
```bash
cp .env.example .env.local
# edit .env.local and paste the two values
npm install
npm run dev
```
Vercel/Netlify: add the same two variables (`VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`) in the project's environment settings and redeploy.
Never use the `service_role` key in this app.

## 5. Create the first admin
1. Open the app and choose **"משרד עורכי דין / חברה? פתיחת חשבון"** → sign up with your own email (confirm the email if required).
2. In **SQL Editor** run (replace the email):
   ```sql
   update public.profiles set role = 'admin' where lower(email) = lower('you@example.com');
   ```
3. Sign out and in again — you now see the admin dashboard.

## 6. Add couriers and lawyers
- **Couriers (self-service join request)**: on the login screen a courier presses **"שליח חדש? הגשת בקשת הצטרפות"** and fills in name, email, password, phone, residence city, work region, license number and business type.
  They receive Supabase's verification email, and the admin gets the notification email (step 7). The courier can sign in only after verifying the email, then sees a *"waiting for approval"* screen until the admin presses **אישור** in *ניהול שליחים* (a badge on that tab counts pending requests). Pending couriers never appear in the dispatch dropdown.
- **Couriers (admin-registered)**: Admin dashboard → *ניהול שליחים* → *הרשמת שליח חדש*. The courier then signs up with **that same email** (either form) and is linked automatically, already approved.
- **Lawyers / companies**: **"משרד עורכי דין / חברה? פתיחת חשבון"** — a short form (name, email, password); role *lawyer*, active immediately after email verification.
  To fill in the details printed in the affidavit's attorney-verification block, run per lawyer:
  ```sql
  update public.profiles
     set firm = 'ישראלי ושות'' — משרד עורכי דין', bar_license_no = '45821',
         office_address = 'שדרות רוטשילד 45, תל אביב', phone = '03-5551234'
   where lower(email) = lower('lawyer@example.com');
  ```
- To make someone an admin later, use the SQL from step 5.

## 7. Courier-registration email to the admin (webhook)

Verification email to the courier = Supabase (step 3, keep **Confirm email ON**; the screen after sign-up tells them to check their inbox).
The **admin notification** is a webhook the app calls right after a successful courier sign-up. Set it up once:

1. In **Make.com**: *Create a new scenario* → add **Webhooks → Custom webhook** → *Add* → copy the URL it shows (looks like `https://hook.eu1.make.com/xxxxxxxx`).
   (Zapier: *Webhooks by Zapier → Catch Hook*.)
2. **Paste the URL** in ONE of these places:
   - **Recommended:** the environment variable `VITE_COURIER_WEBHOOK_URL` — in `.env.local` locally and in Vercel → Project Settings → Environment Variables (then redeploy); or
   - directly in `src/App.jsx`: search for `PASTE_YOUR_WEBHOOK_URL_HERE` (constant `COURIER_WEBHOOK_URL`) and replace that text with your URL.
3. Run one test registration so Make learns the fields, then add an **Email → Send an email** module: *To* = `{{notify_email}}` (already `mesirot.express@gmail.com`), *Subject* = `{{subject}}`, *Body* = `{{message}}` (or map `full_name`, `phone`, `email`, `residence_city`, `region`, `license_number`, `business_type` individually). Turn the scenario **On**.

Fields sent: `event`, `notify_email`, `approval_link`, `submitted_at`, `full_name`, `phone`, `email`, `residence_city`, `region`, `license_number`, `business_type`, `subject`, `message` (form-encoded, `no-cors`, fire-and-forget — a webhook failure never blocks the registration; the password is never sent).
Note: because the call is made from the browser, the webhook URL is visible to anyone who inspects the site. For a tamper-proof alternative use **Supabase → Database → Webhooks** on `INSERT` into `public.profiles` (filter `role = 'courier'`) pointing at the same Make URL.

### 7b. New-order webhook (SMS + e-mail alerts)
Same recipe as above, with a second Make scenario:
1. Make → **Create a new scenario → Webhooks → Custom webhook**, copy the URL.
2. Put it in `VITE_NEW_ORDER_WEBHOOK_URL` (Vercel env var / `.env.local`) **or** replace `PASTE_NEW_ORDER_WEBHOOK_URL_HERE` (constant `NEW_ORDER_WEBHOOK_URL`) in `src/App.jsx`.
3. Submit one test order, then add an **Email → Send an email** module (*Subject* `{{subject}}`, *Body* `{{message}}`) and an SMS module (Twilio / Vonage / etc.) to the client or to the admin.
Fields sent: `event`, `notify_email`, `created_at`, `order_id`, `client_name`, `client_firm`, `client_phone`, `recipient_name`, `recipient_phone`, `city`, `address`, `pricing_zone`, `doc_type`, `case_number`, `court`, `speed`, `urgent`, `addons`, `notes`, `price_total`, `subject`, `message`. In cloud mode it fires only after the order was saved to the database.

### 7c. Order cancellation
A law firm can cancel an order only while no courier is assigned. In cloud mode this runs through the `cancel_order` SQL function (already in `schema.sql` — re-run the file if you set up earlier; it is idempotent), which re-checks the rule on the server.

## 8. How it works
- **Real time**: the app subscribes to `orders`, `visits`, `notifications`, `profiles` and `settings`. A courier's visit report, photo, signature or affidavit appears on the Admin and Lawyer screens within a fraction of a second; Realtime respects the same security rules, so each user only receives their own rows.
- **Files**: photos, videos, audio recordings and signature images are uploaded to the `evidence` bucket under `<ORDER-ID>/...`; the database stores only the public URLs (`visits.photo_url`, `audio_url`, `signature_url`, and the affidavit signature URL inside `orders.data`).
- **Evidence integrity**: `visits` rows can be inserted but never edited or deleted from the app, and storage files are never overwritten.
- **Notifications**: created by database triggers (a client cannot forge them). Lawyers can only mark their own as read.
- **Payroll**: courier payment flags and manual adjustments are stored per courier in `settings` (`payroll:<courierId>`); the admin writes them, each courier reads only their own.

## 9. Security notes
- The anon key is public by design; **Row Level Security is what protects the data** — keep it enabled on every table.
- Evidence URLs are public (unguessable names, but anyone holding a link can open it). If you need private files, switch the bucket to private and replace `getPublicUrl` with signed URLs.
- A courier can edit the orders assigned to them (needed to report visits). A database trigger keeps ownership, the assigned-courier name and the price override admin-only.
- Sign-up metadata can only produce a *lawyer* or a *pending* courier (enforced in the `handle_new_user` trigger); admins can only be created with the SQL in step 5.
- Allowing public sign-up creates *lawyer* accounts that can open orders. To disable it: **Authentication → Providers → Email → disable "Allow new users to sign up"** and create lawyers from **Authentication → Users → Add user** instead.
- The browser stores nothing sensitive besides the Supabase session token.

## 10. Pickup & dispatch (Wolt-style)
1. Re-run `supabase/schema.sql` (idempotent). It adds `orders.region`, `profiles.work_cities`, the `order_responses` table, the region-based visibility rule for open orders, and the triggers that resolve requests when the manager assigns.
2. **Who sees an open order:** approved couriers whose *work region* equals the order's region (derived from the city) and — only if you fill `profiles.work_cities` (a text array, e.g. `{חדרה,נתניה}`) — whose list contains the order's city. Empty `work_cities` = the whole region.
3. **Courier:** new tab "פתוחות" (with a counter), an in-app banner and, if allowed, a system notification when a matching order appears. Buttons "קח הזמנה" / "דחה". Nothing is auto-assigned.
4. **Manager:** under the courier dropdown of each order — a green list of everyone who asked for it with a "שבץ" button, and a red "דחה" tag for decliners (who are also disabled in the dropdown).
5. **Not chosen:** every other taker sees "המסירה נלקחה, אל דאגה יהיו עוד הרבה בהמשך (:" until they dismiss it.
6. Orders created before this update have no region and stay invisible to the open-orders list (they are already assigned or old). To backfill: `update public.orders set region = data->>'region' where region is null;`.
7. Limitation: a courier's browser receives the full row of open orders in their region (including recipient details), because row-level security works per row. If that is a concern, tell me and I will move the recipient details to a table that is only readable after assignment.
8. Phone/SMS alerts when the app is closed: the new-order webhook (7b) now also sends `region` and `city`; in Make, look up couriers of that region and send an SMS.

## 11. Authentication emails
- **Forgot password**: "שכחתי סיסמה" on the login screen → `resetPasswordForEmail` → secure link → the app shows "בחירת סיסמה חדשה" → `updateUser`.
- **Branded e-mails**: Supabase → Authentication → **Email Templates**. Paste `supabase/email-templates/confirm-signup.html` into *Confirm signup* (subject: `אימות כתובת האימייל — משלוחים משפטיים`) and `supabase/email-templates/reset-password.html` into *Reset password* (subject: `איפוס סיסמה — משלוחים משפטיים`). The green "לאימות" button uses `{{ .ConfirmationURL }}`.
- **Auto sign-in after the click**: Authentication → URL Configuration → *Site URL* = `https://mesirot.express`, and add `https://mesirot.express/**` (plus `http://localhost:5173/**` for development) to *Redirect URLs*. Keep Authentication → Providers → Email → *Confirm email* ON. The app sends `emailRedirectTo = VITE_SITE_URL`, so the link brings the user back signed in.
- **Sending reliably**: the built-in Supabase mailer is limited to a few e-mails per hour. For production add your own SMTP (Authentication → SMTP Settings; e.g. Resend / SendGrid / Postmark) with a sender such as `no-reply@mesirot.express`, and add the SPF + DKIM DNS records your provider shows.

## 12. Moving the app to mesirot.express
1. **Vercel** → Project → Settings → Domains → add `mesirot.express` (primary) and `www.mesirot.express`. At your registrar create the DNS records exactly as Vercel displays them (usually an `A` record for the apex and a `CNAME` for `www`). `vercel.json` already redirects `www` → apex and keeps the SPA rewrite.
2. Vercel → Settings → Environment Variables: `VITE_SITE_URL=https://mesirot.express`, then **redeploy**.
3. **Supabase** → Authentication → URL Configuration: Site URL + Redirect URLs as in section 11.
4. **CORS**: nothing to configure. Supabase's REST / Auth / Realtime / Storage endpoints accept requests from any origin (the anon key plus Row Level Security is the protection), and the Make webhooks are sent in `no-cors` mode. Only if you ever put your own proxy/API in front must it allow `https://mesirot.express`.
5. Keep the old `*.vercel.app` URL in *Redirect URLs* until emails sent earlier have expired.
6. Optional: update your Make scenarios' e-mail templates to link to the new domain.

## 13. Order numbers
New orders get `ORD-1001`, `ORD-1002 …` from the database sequence `order_number_seq` (RPC `next_order_id`). To start from another number: `alter sequence public.order_number_seq restart with 2001;`. Demo mode continues after the highest existing number.

## 14. Courier sign-up: verification, approval, admin e-mail
- **Admin e-mail** goes through the Make webhook (section 7). It is sent only if `VITE_COURIER_WEBHOOK_URL` is a real `https://` URL **at build time** — set it in Vercel and *redeploy*. In Make the scenario must be **On** and contain an *Email → Send an email* module (To `{{notify_email}}` = mesirot.express@gmail.com, Subject `{{subject}}`, Body `{{message}}`; the approval link is in `{{approval_link}}`). If nothing arrives, open the browser console on the registration page: "Courier webhook skipped" means the variable is missing from the build.
- **After the e-mail link**: the courier lands on `https://mesirot.express`, is signed out at once and sees the green "האימות בוצע בהצלחה / החשבון ממתין לאישור מנהל" message on the login screen. The admin approves under *ניהול שליחים* (the e-mailed link opens that tab after the admin logs in).
- **Login is blocked** for unapproved couriers both at password login and for any existing session.

## 15. Mobile new-order banner + deep link (admin)
- Files: `public/sw.js` (service worker), `public/manifest.webmanifest`, `public/icon-192.png` / `icon-512.png`, and the links added to `index.html`. Deploy them with the app (no config needed).
- **Enable once per phone:** open the admin dashboard → tap "הפעלת התראות על מסירות חדשות בנייד" → Allow. On **iPhone** (iOS 16.4+) notifications work only after *Share → Add to Home Screen* and opening the app from that icon.
- **What happens:** when a new order appears in the live list (Supabase Realtime), the phone shows the banner "מסירה חדשה (אבא תודה)" with vibration and the system notification sound (browsers cannot play a custom sound). Tapping it opens `https://mesirot.express/#assign=<ORDER_ID>`: the admin dashboard opens, scrolls to that order (highlighted in orange) and shows the orange banner with the courier picker and a "שבץ שליח" button. If the admin is not logged in, the link survives the login screen.
- **Limit:** the banner is raised by the app itself, so the app/PWA must be open or in the background. A banner while the app is fully closed needs server-side Web Push (VAPID keys + a Supabase Edge Function) — not included. For that case use the new-order webhook (7b) to send an SMS/WhatsApp.

## 16. Block / restore users
- Admin → *ניהול שליחים*: next to each approved courier a button "חסום מפעילות" / "החזר לפעילות". Re-run `schema.sql` first (adds `profiles.blocked`, `blocked_at`, the `set_user_blocked` function; blocked users are denied by every policy).
- The block applies to the user id **and** every profile row with the same e-mail. A blocked user who is logged in is signed out immediately (Realtime, or when the tab becomes visible); a blocked user who tries to log in sees "החשבון הושבת מפעילות על ידי המנהל". Blocked couriers disappear from every assignment list (including the orange banner) until restored. Admins cannot be blocked.
- Each block/restore calls the courier webhook with `event` = `user_blocked` / `user_restored`, `email`, `notify_email`, `subject`, `message`. In Make add a Router: one route per event that e-mails `{{notify_email}}` and (optionally) `{{email}}`.
- Lawyer accounts: enforcement is identical, but there is no lawyers list in the UI yet. To block one now: `select public.set_user_blocked('<profile id>', true);` as an admin, or `update public.profiles set blocked = true where lower(email) = lower('x@y.com');`

## 17. Access guard
- The portals render only when a live Supabase session exists **and** its profile belongs to that session, has a known role (admin / courier / lawyer) and is not blocked. Otherwise only the login screen is shown. A signed-in user is pinned to the portal of their role (a courier cannot reach the admin screens), and data is protected again on the server by Row Level Security.
- Logout ends the session, wipes the stored token and the deep link, and unmounts all app data; other tabs of the same browser are signed out too. A URL never carries a session.
- Production builds without `VITE_SUPABASE_URL` / `VITE_SUPABASE_ANON_KEY` no longer fall back to the open demo mode — they show a "not configured" message. Demo mode works only in `npm run dev` (or with `VITE_ALLOW_DEMO=true`, not recommended in production).

## 18. "הישאר מחובר" and instant block enforcement
- The login form has a **הישאר מחובר** checkbox (UNCHECKED by default — session-only unless ticked). Checked: the Supabase session is kept in `localStorage` (survives restarts, shared by all tabs). Unchecked: it is kept in `sessionStorage` — only the current tab; a new tab or a restarted browser asks for a fresh login. Implemented with a custom storage adapter passed to `createClient` (`authStorage` in `src/App.jsx`).
- A blocked user is removed regardless of that choice: the profile is re-read at every app load and login, pushed by Realtime (`profiles` UPDATE on the user's own row) and re-checked whenever the tab becomes visible. On `blocked = true` the app calls `supabase.auth.signOut()`, clears its state and shows "החשבון הושבת מפעילות על ידי המנהל" on the login screen. The database also denies a blocked user's data requests (section 16), so a cached session cannot read anything.
- Default is **session-only**: a new browser, a private window or a new tab always lands on the login screen. When this version first loads, any token that older versions left in `localStorage` is deleted (users sign in once more).
- **Startup guard** (`STARTUP SESSION GUARD` in `src/App.jsx`, before `createClient`): unless "הישאר מחובר" was ticked, every fresh visit (link click, typed address, new tab, app relaunch) deletes stored Supabase tokens first, so the login screen always opens. Only a plain reload (F5) keeps a non-"stay" session in the same tab. Verification / reset links are exempt (their tokens are in the URL). To make even F5 require a login, change `navType !== "reload"` to `true` in that block.
